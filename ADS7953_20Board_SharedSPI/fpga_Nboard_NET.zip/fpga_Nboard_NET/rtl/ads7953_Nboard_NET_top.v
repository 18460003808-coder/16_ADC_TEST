`timescale 1ns/1ps
`include "rtl/ads7953_board_count.vh"

module ads7953_Nboard_NET_top #(
    parameter integer CLK_HZ      = 50_000_000,
    parameter integer ADC_SCLK_HZ = 10_000_000,
    parameter [4:0] BOARD_COUNT   = `ADS7953_BOARD_COUNT
)(
    input  wire        clk,
    input  wire        rst_n,
    output wire [19:0] adc_cs_n,
    output wire        adc_sclk,
    output wire        adc_sdi,
    input  wire        adc_sdo,

    input  wire        e_rxc,
    input  wire [7:0]  e_rxd,
    input  wire        e_rxdv,
    input  wire        e_rxer,
    output wire        e_gtxc,
    output wire [7:0]  e_txd,
    output wire        e_txen,
    output wire        e_txer,
    output wire        e_reset_n,
    output wire        e_mdc,
    inout  wire        e_mdio,

    output wire        ready,
    output wire        busy,
    output wire        packet_busy
);
    wire clk_125m;
    wire pll_locked;
    wire start_scans;
    wire scans_done;
    wire [3839:0] board_codes;

    gmii_pll_125m u_gmii_pll (
        .inclk0(clk),
        .areset(~rst_n),
        .c0(clk_125m),
        .locked(pll_locked)
    );

    ads7953_udp_gmii #(
        .BOARD_COUNT(BOARD_COUNT)
    ) u_udp (
        .clk_50m(clk),
        .clk_125m(clk_125m),
        .rst_n(rst_n),
        .pll_locked(pll_locked),
        .adc_ready(ready),
        .scans_done(scans_done),
        .board_codes(board_codes),
        .start_scans(start_scans),
        .packet_busy(packet_busy),
        .gmii_rx_clk(e_rxc),
        .gmii_rxd(e_rxd),
        .gmii_rx_dv(e_rxdv),
        .gmii_rx_er(e_rxer),
        .gmii_gtx_clk(e_gtxc),
        .gmii_txd(e_txd),
        .gmii_tx_en(e_txen),
        .gmii_tx_er(e_txer),
        .phy_reset_n(e_reset_n),
        .mdc(e_mdc),
        .mdio(e_mdio)
    );

    ads7953_Nboard_controller #(
        .CLK_HZ(CLK_HZ),
        .SCLK_HZ(ADC_SCLK_HZ),
        .BOARD_GAP_NS(100),
        .BOARD_COUNT(BOARD_COUNT)
    ) u_controller (
        .clk(clk),
        .rst_n(rst_n),
        .start(start_scans),
        .adc_cs_n(adc_cs_n),
        .adc_sclk(adc_sclk),
        .adc_sdi(adc_sdi),
        .adc_sdo(adc_sdo),
        .ready(ready),
        .busy(busy),
        .all_done(scans_done),
        .board_codes(board_codes),
        .sample_valid(),
        .sample_board(),
        .sample_channel(),
        .sample_code()
    );
endmodule
